class FFProbeError(Exception):
    pass
